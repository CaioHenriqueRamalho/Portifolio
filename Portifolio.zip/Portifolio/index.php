<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dev Ramalho</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    
</head>
<body>
    <header>
        <nav>
            <div class="logo">Caio Ramalho</div>
            <ul class="nav-links">
                <li><a href="#home">Início</a></li>
                <li><a href="#about">Sobre</a></li>
                <li><a href="#jornada">Experiência</a></li>
                <li><a href="#skills">Habilidades</a></li>
                <li><a href="#projects">Projetos</a></li>
                <li><a href="#contact">Contato</a></li>
            </ul>
            <button class="hamburger">☰</button>
        </nav>
    </header>

    <section id="home" class="hero">
        <div class="hero-content">
            <h1>Olá, eu sou <span class="highlight">Caio Ramalho</span></h1>
            <p>Desenvolvedor Full Stack especializado na criação e gestão de sites e aplicações web, garantindo alto desempenho, usabilidade e escalabilidade para o sucesso do produto.</p>
            <a href="#projects" class="btn">Ver Projetos</a>
        </div>
    </section>

    <section id="about">
        <div class="section-title">
            <h2>Sobre Mim</h2>
            <p>Conheça um pouco da minha história e experiência</p>
        </div>
        <div class="about-content">
            <div class="about-img">
                <img src="image/logosite.jpg" alt="Minha foto">
            </div>
            <div class="about-text">
                <p>Olá! Sou um Desenvolvedor web apaixonado por criar experiências digitais incríveis. Com mais de 5 anos de experiência no mercado, tenho trabalhado com diversas tecnologias e frameworks para desenvolver soluções eficientes e visualmente atraentes.</p>
                <p>Minha jornada começou na faculdade de Analise e Desenvolvimento de Sistema pela Unimar- Universidade de Marília, onde descobri minha paixão por desenvolvimento web. Desde então, venho me aprimorando constantemente e buscando novos desafios.</p>
                <p>Quando não estou codificando, gosto de ler livros sobre tecnologia, praticar esportes com(Musculação, Futebol, etc).</p>
            </div>
        </div>
        <form>
            
        </form>
    </section>
    <section id="jornada" class="career">
        <div class="section-title">
            <h2>JORNADA</h2>
            <p>Minha trajetória profissional</p>
        </div>
        <div class="timeline-container">
            <div class="timeline">
                <div class="timeline-line"></div>
                
                <!-- Item 1 -->
                <div class="timeline-item right">
                    <div class="timeline-dot"></div>
                    <div class="timeline-content">
                        <h3>Dev Full Stack</h3>
                        <h4>Scaquete Sistemas</h4>
                        <div class="timeline-date">
                            <span class="date-icon">📅</span>
                            <span>Jun, 2022 - Ago, 2025</span>
                        </div>
                    </div>
                </div>
                
                <!-- Item 2 -->
                <div class="timeline-item left">
                    <div class="timeline-dot"></div>
                    <div class="timeline-content">
                        <h3>Estagio</h3>
                        <h4>Union Tecnologia</h4>
                        <div class="timeline-date">
                            <span class="date-icon">📅</span>
                            <span>Mar, 2022 - Jun, 2022</span>
                        </div>
                    </div>
                </div>
               
            </div>
        </div>
    </section>
    
    

    <section id="skills" class="skills">
        <div class="section-title">
            <h2>Minhas Habilidades</h2>
            <p>Tecnologias e ferramentas que domino</p>
        </div>
        <div class="skills-content">
            <div class="skill-categories">
                <div class="skill-category">
                    <h3>Desenvolvimento Front-end</h3>
                    <div class="skill-bar">
                        <div class="skill-info">
                            <span>HTML/CSS</span>
                            <span>100%</span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress" style="width: 100%;"></div>
                        </div>
                    </div>
                    <div class="skill-bar">
                        <div class="skill-info">
                            <span>JavaScript</span>
                            <span>90%</span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress" style="width: 90%;"></div>
                        </div>
                    </div>
                </div>
                <div class="skill-category">
                    <h3>Desenvolvimento Back-end</h3>
                    <div class="skill-bar">
                        <div class="skill-info">
                            <span>PHP</span>
                            <span>95%</span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress" style="width: 95%;"></div>
                        </div>
                    </div>
                    <div class="skill-bar">
                        <div class="skill-info">
                            <span>Firebird</span>
                            <span>95%</span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress" style="width: 95%;"></div>
                        </div>
                    </div>
                    <div class="skill-bar">
                        <div class="skill-info">
                            <span>MySQL/Oracle/PostgreSql</span>
                            <span>85%</span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress" style="width: 85%;"></div>
                        </div>
                    </div>
                </div>
                <div class="skill-category">
                    <h3>Ferramentas & Outros</h3>
                    <div class="skill-bar">
                        <div class="skill-info">
                            <span>Git/GitHub</span>
                            <span>100%</span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress" style="width: 100%;"></div>
                        </div>
                    </div>
                    <div class="skill-bar">
                        <div class="skill-info">
                            <span>Laravel</span>
                            <span>90%</span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress" style="width: 90%;"></div>
                        </div>
                    </div>
                    <div class="skill-bar">
                        <div class="skill-info">
                            <span>Adianti Framework</span>
                            <span>95%</span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress" style="width: 95%;"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="projects" class="portfolio">
        <div class="section-title">
            <h2>Meus Projetos</h2>
            <p>Confira alguns dos meus trabalhos recentes</p>
        </div>
      <div class="projects">
    <div class="project">
        <div class="project-info">
            <h3>API Receita</h3>
            <p>API que realiza a leitura de QR Codes em receituários médicos, validando a autenticidade e exibindo o nome da instituição e do médico responsável.</p>
            <div class="project-links">
                <a href="https://github.com/CaioHenriqueRamalho/ApiGota.git" target="_blank">GitHub</a>
            </div>
        </div>
    </div>
</div>
        <div class="projects">
            <div class="project">
                <div class="project-info">
                    <h3>E-commerce Responsivo</h3>
                    <p>Desenvolvimento de loja virtual com painel administrativo e integração de pagamentos.</p>
                    <div class="project-links">                        
                        <a href="https://github.com/CaioHenriqueRamalho/ApiGota.git">GitHub</a>
                    </div>
                </div>
            </div>
            <div class="project">
                <div class="project-info">
                    <h3>Validador de XSS</h3>
                    <p>Sistema de validação para evitar riscos potenciais de ataques de injeção.</p>
                    <div class="project-links">
                        <a href="https://github.com/CaioHenriqueRamalho/ProjetoMINI.git">GitHub</a>
                    </div>
                </div>
            </div>
            <div class="project">
               
                <div class="project-info">
                    <h3>Previsão Climatica</h3>
                    <p>Projeto para analise de solo e para Previsão Climatica</p>
                    <div class="project-links">
                        <a href="https://github.com/Felipemlzita/base.git">GitHub</a>
                    </div>
                </div>
            </div>
            <div class="project">
                <div class="project-info">
                    <h3>API de Produtos</h3>
                    <p>Projeto de um API de Produtos que efetua um CRUD</p>
                    <div class="project-links">
                        <a href="https://github.com/CaioHenriqueRamalho/Api-de-Produto.git">GitHub</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
        <div class="section-title">
            <h2>Entre em Contato</h2>
            <p>Vamos trabalhar juntos no seu próximo projeto</p>
        </div>
        <div class="contact-content">
            <div class="contact-info">
                <div class="contact-item">
                    <div class="contact-icon">✉️</div>
                    <h3>Email</h3>
                    <p>caioramalho1602@gmail.com</p>
                </div>
                <div class="contact-item">
                    <div class="contact-icon">📱</div>
                    <h3>Telefone</h3>
                    <p>+55 (14) 99635-1602</p>
                </div>
                <div class="contact-item">
                    <div class="contact-icon">📍</div>
                    <h3>Localização</h3>
                    <p>Marília, Brasil</p>
                </div>
            </div>
        </div>
    

    <footer>
        <ul class="social-links">
            <li><a href="https://www.linkedin.com/in/caio-henrique-ramalho-5b1b12207"><i class="fab fa-linkedin" style="color: #ffff; font-size: 32px;"></i></a></li>
            <li><a href="https://www.github.com/CaioHenriqueRamalho"><i class="fab fa-github" style="color: #ffff; font-size: 32px;"></i></a></li>
            <li><a href="https://www.instagram.com/dev_Ramalho"> <i class="fab fa-instagram" style="color: #ffff; font-size: 32px;"></i></a></li>
        </ul>
        <p>&copy; 2025 Caio Ramalho. Todos os direitos reservados.</p>
    </footer>

    <script>
        // Menu de navegação mobile
        const hamburger = document.querySelector('.hamburger');
        const navLinks = document.querySelector('.nav-links');
        
        hamburger.addEventListener('click', () => {
            navLinks.classList.toggle('active');
        });
        
        // Fechar menu ao clicar em um link
        document.querySelectorAll('.nav-links a').forEach(link => {
            link.addEventListener('click', () => {
                navLinks.classList.remove('active');
            });
        });
    </script>
</body>
</html>



